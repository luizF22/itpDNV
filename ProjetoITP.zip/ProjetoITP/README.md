# Meu Projeto ITP

## Descrição
[Descreva seu projeto aqui]

## Como compilar
g++ -Iinclude src/*.cpp -o programa
