#include "mapa_altitudes.h"
#include <fstream>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

// ═══════════════════════════════════════════════════════════
// CONSTRUTORES E DESTRUTOR
// ═══════════════════════════════════════════════════════════

MapaAltitudes::MapaAltitudes() : tamanho(0), altitudes(nullptr) {}

MapaAltitudes::MapaAltitudes(int N) : tamanho(0), altitudes(nullptr) {
    size_t tam = static_cast<size_t>(pow(2, N)) + 1;
    alocar(tam);
}

MapaAltitudes::~MapaAltitudes() {
    liberar();
}

// ═══════════════════════════════════════════════════════════
// MÉTODOS AUXILIARES PRIVADOS
// ═══════════════════════════════════════════════════════════

size_t MapaAltitudes::calcularIndice(size_t lin, size_t col) const {
    return lin * tamanho + col;
}

void MapaAltitudes::liberar() {
    if (altitudes != nullptr) {
        delete[] altitudes;
        altitudes = nullptr;
    }
    tamanho = 0;
}

void MapaAltitudes::alocar(size_t tam) {
    liberar();
    tamanho = tam;
    
    if (tamanho > 0) {
        altitudes = new double[tamanho * tamanho];
        // Inicializa com zeros
        for (size_t i = 0; i < tamanho * tamanho; i++) {
            altitudes[i] = 0.0;
        }
    }
}

// Obtém altitude com verificação de limites (retorna valor padrão se fora)
double MapaAltitudes::obterAltitudaSegura(int lin, int col, double padrao) const {
    if (lin < 0 || col < 0 || 
        lin >= static_cast<int>(tamanho) || 
        col >= static_cast<int>(tamanho)) {
        return padrao;
    }
    return altitudes[calcularIndice(lin, col)];
}

// ═══════════════════════════════════════════════════════════
// ALGORITMO DIAMOND-SQUARE
// ═══════════════════════════════════════════════════════════

void MapaAltitudes::etapaDiamond(size_t x, size_t y, size_t passo, double amplitude) {
    // Calcula o centro do quadrado
    size_t meio = passo / 2;
    size_t centroX = x + meio;
    size_t centroY = y + meio;
    
    // Obtém os 4 cantos
    double cantoA = altitudes[calcularIndice(y, x)];              // Superior esquerdo
    double cantoB = altitudes[calcularIndice(y, x + passo)];     // Superior direito
    double cantoC = altitudes[calcularIndice(y + passo, x)];     // Inferior esquerdo
    double cantoD = altitudes[calcularIndice(y + passo, x + passo)]; // Inferior direito
    
    // Média dos 4 cantos + deslocamento aleatório
    double media = (cantoA + cantoB + cantoC + cantoD) / 4.0;
    double deslocamento = ((double)rand() / RAND_MAX * 2.0 - 1.0) * amplitude;
    
    altitudes[calcularIndice(centroY, centroX)] = media + deslocamento;
}

void MapaAltitudes::etapaSquare(size_t x, size_t y, size_t passo, double amplitude) {
    size_t meio = passo / 2;
    size_t centroX = x + meio;
    size_t centroY = y + meio;
    
    double centro = altitudes[calcularIndice(centroY, centroX)];
    
    // Calcula os 4 pontos médios das bordas (cima, esquerda, direita, baixo)
    
    // Ponto superior (y, centroX)
    if (y > 0 || x == 0) {  // Garante que não recalcula pontos já feitos
        double soma = centro;
        int cont = 1;
        
        soma += obterAltitudaSegura(y, x, centro);              // Esquerda
        cont++;
        soma += obterAltitudaSegura(y, x + passo, centro);      // Direita
        cont++;
        soma += obterAltitudaSegura(y - meio, centroX, centro); // Cima
        cont++;
        
        double media = soma / cont;
        double deslocamento = ((double)rand() / RAND_MAX * 2.0 - 1.0) * amplitude;
        altitudes[calcularIndice(y, centroX)] = media + deslocamento;
    }
    
    // Ponto esquerdo (centroY, x)
    if (x > 0 || y == 0) {
        double soma = centro;
        int cont = 1;
        
        soma += obterAltitudaSegura(y, x, centro);              // Cima
        cont++;
        soma += obterAltitudaSegura(y + passo, x, centro);      // Baixo
        cont++;
        soma += obterAltitudaSegura(centroY, x - meio, centro); // Esquerda
        cont++;
        
        double media = soma / cont;
        double deslocamento = ((double)rand() / RAND_MAX * 2.0 - 1.0) * amplitude;
        altitudes[calcularIndice(centroY, x)] = media + deslocamento;
    }
    
    // Ponto direito (centroY, x + passo)
    {
        double soma = centro;
        int cont = 1;
        
        soma += obterAltitudaSegura(y, x + passo, centro);          // Cima
        cont++;
        soma += obterAltitudaSegura(y + passo, x + passo, centro);  // Baixo
        cont++;
        soma += obterAltitudaSegura(centroY, x + passo + meio, centro); // Direita
        cont++;
        
        double media = soma / cont;
        double deslocamento = ((double)rand() / RAND_MAX * 2.0 - 1.0) * amplitude;
        altitudes[calcularIndice(centroY, x + passo)] = media + deslocamento;
    }
    
    // Ponto inferior (y + passo, centroX)
    {
        double soma = centro;
        int cont = 1;
        
        soma += obterAltitudaSegura(y + passo, x, centro);          // Esquerda
        cont++;
        soma += obterAltitudaSegura(y + passo, x + passo, centro);  // Direita
        cont++;
        soma += obterAltitudaSegura(y + passo + meio, centroX, centro); // Baixo
        cont++;
        
        double media = soma / cont;
        double deslocamento = ((double)rand() / RAND_MAX * 2.0 - 1.0) * amplitude;
        altitudes[calcularIndice(y + passo, centroX)] = media + deslocamento;
    }
}

void MapaAltitudes::gerar(int N, double rugosidade) {
    // Calcula tamanho: 2^N + 1
    size_t tam = static_cast<size_t>(pow(2, N)) + 1;
    alocar(tam);
    
    // Inicializa gerador de números aleatórios
    srand(static_cast<unsigned int>(time(nullptr)));
    
    // Define alturas aleatórias para os 4 cantos [0, 1]
    altitudes[calcularIndice(0, 0)] = (double)rand() / RAND_MAX;
    altitudes[calcularIndice(0, tamanho - 1)] = (double)rand() / RAND_MAX;
    altitudes[calcularIndice(tamanho - 1, 0)] = (double)rand() / RAND_MAX;
    altitudes[calcularIndice(tamanho - 1, tamanho - 1)] = (double)rand() / RAND_MAX;
    
    // Amplitude inicial
    double amplitude = 1.0;
    
    // Loop principal: reduz o passo pela metade a cada iteração
    for (size_t passo = tamanho - 1; passo > 1; passo /= 2) {
        // Para cada quadrado neste nível
        for (size_t y = 0; y < tamanho - 1; y += passo) {
            for (size_t x = 0; x < tamanho - 1; x += passo) {
                etapaDiamond(x, y, passo, amplitude);
            }
        }
        
        // Para cada losango neste nível
        for (size_t y = 0; y < tamanho - 1; y += passo) {
            for (size_t x = 0; x < tamanho - 1; x += passo) {
                etapaSquare(x, y, passo, amplitude);
            }
        }
        
        // Reduz amplitude pela rugosidade
        amplitude *= rugosidade;
    }
}

// ═══════════════════════════════════════════════════════════
// MÉTODOS DE CONSULTA
// ═══════════════════════════════════════════════════════════

double MapaAltitudes::obterAltitude(size_t lin, size_t col) const {
    return altitudes[calcularIndice(lin, col)];
}

size_t MapaAltitudes::obterLinhas() const {
    return tamanho;
}

size_t MapaAltitudes::obterColunas() const {
    return tamanho;
}

// ═══════════════════════════════════════════════════════════
// I/O DE ARQUIVOS
// ═══════════════════════════════════════════════════════════

bool MapaAltitudes::salvar(const char* nomeArquivo) const {
    ofstream arquivo(nomeArquivo);
    if (!arquivo.is_open()) {
        cerr << "Erro ao criar arquivo: " << nomeArquivo << "\n";
        return false;
    }
    
    // Escreve dimensões
    arquivo << tamanho << " " << tamanho << "\n";
    
    // Escreve altitudes (uma por linha para facilitar leitura)
    for (size_t i = 0; i < tamanho * tamanho; i++) {
        arquivo << altitudes[i] << "\n";
    }
    
    arquivo.close();
    return true;
}

bool MapaAltitudes::ler(const char* nomeArquivo) {
    ifstream arquivo(nomeArquivo);
    if (!arquivo.is_open()) {
        cerr << "Erro ao abrir arquivo: " << nomeArquivo << "\n";
        return false;
    }
    
    // Lê dimensões
    size_t linhas, colunas;
    arquivo >> linhas >> colunas;
    
    if (linhas != colunas) {
        cerr << "Erro: mapa deve ser quadrado\n";
        return false;
    }
    
    // Aloca memória
    alocar(linhas);
    
    // Lê altitudes
    for (size_t i = 0; i < tamanho * tamanho; i++) {
        arquivo >> altitudes[i];
        if (arquivo.fail()) {
            cerr << "Erro ao ler altitude " << i << "\n";
            return false;
        }
    }
    
    arquivo.close();
    return true;
}