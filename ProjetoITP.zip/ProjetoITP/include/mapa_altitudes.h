#ifndef MAPA_ALTITUDES_H
#define MAPA_ALTITUDES_H

#include <cstddef>

class MapaAltitudes {
private:
    size_t tamanho;      // Sempre 2^N + 1 (ex: 3, 5, 9, 17, 33...)
    double* altitudes;   // Array único (linear) para matriz tamanho×tamanho
    
    // Métodos auxiliares privados
    size_t calcularIndice(size_t lin, size_t col) const;
    void liberar();
    void alocar(size_t tam);
    
    // Métodos do algoritmo Diamond-Square
    void etapaDiamond(size_t x, size_t y, size_t passo, double amplitude);
    void etapaSquare(size_t x, size_t y, size_t passo, double amplitude);
    double obterAltitudaSegura(int lin, int col, double padrao) const;

public:
    // Construtores e destrutor
    MapaAltitudes();                    // Construtor padrão (vazio)
    explicit MapaAltitudes(int N);      // Construtor com tamanho 2^N + 1
    ~MapaAltitudes();                   // Destrutor
    
    // Geração de mapa
    void gerar(int N, double rugosidade);
    
    // Consultas
    double obterAltitude(size_t lin, size_t col) const;
    size_t obterLinhas() const;
    size_t obterColunas() const;
    
    // I/O de arquivos
    bool salvar(const char* nomeArquivo) const;
    bool ler(const char* nomeArquivo);
};

#endif